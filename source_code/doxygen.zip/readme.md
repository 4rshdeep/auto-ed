We have made several modules, description is as follows.
 * input.cpp - handles all input related
 * matrices.cpp - handles all matrix operations that would be required
 * Output.cpp - handles all output related
 * threeD_to_ortho.cpp - handles all 3D to 2D transformation
 * twoD_to_threeD.cpp - handles all 2D to 3D transformations