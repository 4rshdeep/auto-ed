var searchData=
[
  ['x',['x',['../structcoordinate.html#a8480dda1b2992713d4b0750bbdf1ee4e',1,'coordinate']]]
];
