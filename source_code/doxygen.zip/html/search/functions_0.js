var searchData=
[
  ['check_5fedges',['check_edges',['../classtwoD__to__threeD.html#acb9f42a6c607ed529dbb381cd1f27117',1,'twoD_to_threeD']]],
  ['check_5ffaces',['check_faces',['../classtwoD__to__threeD.html#a0079e83af6c44d939946fc557a2bbf1b',1,'twoD_to_threeD']]],
  ['check_5fvertices',['check_vertices',['../classtwoD__to__threeD.html#a6d97ae7afa4fd5ca63c9a139298dd2c9',1,'twoD_to_threeD']]]
];
