var searchData=
[
  ['direction',['direction',['../structdirection.html',1,'']]]
];
