var searchData=
[
  ['adjacency_5flist',['adjacency_list',['../structadjacency__list.html',1,'']]]
];
