var searchData=
[
  ['z',['z',['../structcoordinate.html#ab8b9dc71d55e188e1d88dc317509c629',1,'coordinate']]]
];
