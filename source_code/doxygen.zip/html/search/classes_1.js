var searchData=
[
  ['coordinate',['coordinate',['../structcoordinate.html',1,'']]]
];
