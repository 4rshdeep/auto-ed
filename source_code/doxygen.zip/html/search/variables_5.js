var searchData=
[
  ['y',['y',['../structcoordinate.html#a1f90088affc8f61daa374403f148eeb7',1,'coordinate']]]
];
