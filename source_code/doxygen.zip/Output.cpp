#include <bits/stdc++.h>
using namespace std;

class Output
{
public:
	
	bool save_or_not(){
		/*!	Asks user if he/she desires to save the output file that has been generated.
		*/
	}

	string Output_file_name(){
		/*!	Asks user the name which the user desires to give to the Output file.
		*/
	}

	void save_output(bool save_or_not, string Output_file_name ){
		/*!	Checks if the user wants to save the output
		*	Saves the output generated in the corresponding format with the file name specified by the user. 
		*/	
	}

};