#include <bits/stdc++.h>

using namespace std;

class matrices
{
public:

	int* mult4x4(int arr1[][], int arr2[][]) {
	/*! Takes 2 4X4 matrices as input and returns their product as the output.
	*/
	}

	int* inv4x4(int arr[][]) {
	/*! Takes a 4X4 matrix as input and returns its inverse as the output.
	*/
	}	
};